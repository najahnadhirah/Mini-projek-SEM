<footer class="main-footer">
    <div class="pull-right hidden-xs">
     
    </div>
    <strong>&copy; 2019 - Library Management System | Brought To You By <a href="https://oneB.com/">One-B</a></strong>
</footer>